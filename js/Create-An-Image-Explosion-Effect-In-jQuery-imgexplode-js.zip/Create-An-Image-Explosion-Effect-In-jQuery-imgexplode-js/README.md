# jquery-image-explode
[![NPM version][npm-image]][npm-url]
#### A very simple demo
[http://blackmiaool.com/jquery-image-explode](http://blackmiaool.com/jquery-image-explode)
#### Playground
[http://blackmiaool.com/jquery-image-explode/playground.html](http://blackmiaool.com/jquery-image-explode/playground.html)


[npm-url]: https://www.npmjs.com/package/jquery-image-explode
[npm-image]: https://img.shields.io/npm/v/jquery-image-explode.svg
